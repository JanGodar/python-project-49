### Hexlet tests and linter status:
[![Actions Status](https://github.com/JanGodar/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/JanGodar/python-project-49/actions)

<a href="https://codeclimate.com/github/JanGodar/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/cca643fa213af6671033/maintainability" /></a>

https://asciinema.org/connect/2b4db65f-f754-47ab-912c-cc37d2109537

step 6 (brain-calc): https://asciinema.org/a/INehtgnZKUXR2ytWv2Rl0j3Ut


