### Hexlet tests and linter status:
[![Actions Status](https://github.com/JanGodar/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/JanGodar/python-project-49/actions)


https://asciinema.org/connect/2b4db65f-f754-47ab-912c-cc37d2109537



