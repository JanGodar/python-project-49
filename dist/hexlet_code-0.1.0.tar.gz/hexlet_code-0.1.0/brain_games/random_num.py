from random import randint


def make_num():
    num = randint(1, 100)
    return num
